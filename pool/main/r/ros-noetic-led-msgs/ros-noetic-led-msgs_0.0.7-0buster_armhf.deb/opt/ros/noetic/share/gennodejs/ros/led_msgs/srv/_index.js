
"use strict";

let SetLED = require('./SetLED.js')
let SetLEDs = require('./SetLEDs.js')

module.exports = {
  SetLED: SetLED,
  SetLEDs: SetLEDs,
};
