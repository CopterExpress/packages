
"use strict";

let TFSubscriptionGoal = require('./TFSubscriptionGoal.js');
let TFSubscriptionActionFeedback = require('./TFSubscriptionActionFeedback.js');
let TFSubscriptionAction = require('./TFSubscriptionAction.js');
let TFSubscriptionResult = require('./TFSubscriptionResult.js');
let TFSubscriptionActionGoal = require('./TFSubscriptionActionGoal.js');
let TFSubscriptionFeedback = require('./TFSubscriptionFeedback.js');
let TFSubscriptionActionResult = require('./TFSubscriptionActionResult.js');
let TFArray = require('./TFArray.js');

module.exports = {
  TFSubscriptionGoal: TFSubscriptionGoal,
  TFSubscriptionActionFeedback: TFSubscriptionActionFeedback,
  TFSubscriptionAction: TFSubscriptionAction,
  TFSubscriptionResult: TFSubscriptionResult,
  TFSubscriptionActionGoal: TFSubscriptionActionGoal,
  TFSubscriptionFeedback: TFSubscriptionFeedback,
  TFSubscriptionActionResult: TFSubscriptionActionResult,
  TFArray: TFArray,
};
