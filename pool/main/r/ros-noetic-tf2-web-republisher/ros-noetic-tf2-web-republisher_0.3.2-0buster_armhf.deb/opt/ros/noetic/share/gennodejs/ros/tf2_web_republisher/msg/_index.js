
"use strict";

let TFSubscriptionAction = require('./TFSubscriptionAction.js');
let TFSubscriptionGoal = require('./TFSubscriptionGoal.js');
let TFSubscriptionResult = require('./TFSubscriptionResult.js');
let TFSubscriptionActionResult = require('./TFSubscriptionActionResult.js');
let TFSubscriptionActionFeedback = require('./TFSubscriptionActionFeedback.js');
let TFSubscriptionFeedback = require('./TFSubscriptionFeedback.js');
let TFSubscriptionActionGoal = require('./TFSubscriptionActionGoal.js');
let TFArray = require('./TFArray.js');

module.exports = {
  TFSubscriptionAction: TFSubscriptionAction,
  TFSubscriptionGoal: TFSubscriptionGoal,
  TFSubscriptionResult: TFSubscriptionResult,
  TFSubscriptionActionResult: TFSubscriptionActionResult,
  TFSubscriptionActionFeedback: TFSubscriptionActionFeedback,
  TFSubscriptionFeedback: TFSubscriptionFeedback,
  TFSubscriptionActionGoal: TFSubscriptionActionGoal,
  TFArray: TFArray,
};
