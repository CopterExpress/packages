
"use strict";

let tfMessage = require('./tfMessage.js');

module.exports = {
  tfMessage: tfMessage,
};
