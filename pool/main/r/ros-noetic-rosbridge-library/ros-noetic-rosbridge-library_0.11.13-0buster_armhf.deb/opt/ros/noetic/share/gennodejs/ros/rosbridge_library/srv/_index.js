
"use strict";

let SendBytes = require('./SendBytes.js')
let TestEmpty = require('./TestEmpty.js')
let TestMultipleRequestFields = require('./TestMultipleRequestFields.js')
let TestMultipleResponseFields = require('./TestMultipleResponseFields.js')
let TestRequestAndResponse = require('./TestRequestAndResponse.js')
let TestResponseOnly = require('./TestResponseOnly.js')
let AddTwoInts = require('./AddTwoInts.js')
let TestArrayRequest = require('./TestArrayRequest.js')
let TestRequestOnly = require('./TestRequestOnly.js')
let TestNestedService = require('./TestNestedService.js')

module.exports = {
  SendBytes: SendBytes,
  TestEmpty: TestEmpty,
  TestMultipleRequestFields: TestMultipleRequestFields,
  TestMultipleResponseFields: TestMultipleResponseFields,
  TestRequestAndResponse: TestRequestAndResponse,
  TestResponseOnly: TestResponseOnly,
  AddTwoInts: AddTwoInts,
  TestArrayRequest: TestArrayRequest,
  TestRequestOnly: TestRequestOnly,
  TestNestedService: TestNestedService,
};
