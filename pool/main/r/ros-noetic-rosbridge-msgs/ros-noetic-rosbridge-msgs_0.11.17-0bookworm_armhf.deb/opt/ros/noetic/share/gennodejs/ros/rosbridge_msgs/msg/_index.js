
"use strict";

let ConnectedClient = require('./ConnectedClient.js');
let ConnectedClients = require('./ConnectedClients.js');

module.exports = {
  ConnectedClient: ConnectedClient,
  ConnectedClients: ConnectedClients,
};
