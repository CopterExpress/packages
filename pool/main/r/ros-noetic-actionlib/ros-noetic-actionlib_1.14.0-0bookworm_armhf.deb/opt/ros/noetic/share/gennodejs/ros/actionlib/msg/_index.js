
"use strict";

let TwoIntsGoal = require('./TwoIntsGoal.js');
let TestRequestGoal = require('./TestRequestGoal.js');
let TwoIntsActionFeedback = require('./TwoIntsActionFeedback.js');
let TestGoal = require('./TestGoal.js');
let TestActionGoal = require('./TestActionGoal.js');
let TestRequestActionFeedback = require('./TestRequestActionFeedback.js');
let TwoIntsActionResult = require('./TwoIntsActionResult.js');
let TwoIntsResult = require('./TwoIntsResult.js');
let TwoIntsActionGoal = require('./TwoIntsActionGoal.js');
let TwoIntsFeedback = require('./TwoIntsFeedback.js');
let TestRequestActionGoal = require('./TestRequestActionGoal.js');
let TestRequestFeedback = require('./TestRequestFeedback.js');
let TestActionResult = require('./TestActionResult.js');
let TestRequestResult = require('./TestRequestResult.js');
let TestFeedback = require('./TestFeedback.js');
let TestResult = require('./TestResult.js');
let TwoIntsAction = require('./TwoIntsAction.js');
let TestRequestAction = require('./TestRequestAction.js');
let TestActionFeedback = require('./TestActionFeedback.js');
let TestRequestActionResult = require('./TestRequestActionResult.js');
let TestAction = require('./TestAction.js');

module.exports = {
  TwoIntsGoal: TwoIntsGoal,
  TestRequestGoal: TestRequestGoal,
  TwoIntsActionFeedback: TwoIntsActionFeedback,
  TestGoal: TestGoal,
  TestActionGoal: TestActionGoal,
  TestRequestActionFeedback: TestRequestActionFeedback,
  TwoIntsActionResult: TwoIntsActionResult,
  TwoIntsResult: TwoIntsResult,
  TwoIntsActionGoal: TwoIntsActionGoal,
  TwoIntsFeedback: TwoIntsFeedback,
  TestRequestActionGoal: TestRequestActionGoal,
  TestRequestFeedback: TestRequestFeedback,
  TestActionResult: TestActionResult,
  TestRequestResult: TestRequestResult,
  TestFeedback: TestFeedback,
  TestResult: TestResult,
  TwoIntsAction: TwoIntsAction,
  TestRequestAction: TestRequestAction,
  TestActionFeedback: TestActionFeedback,
  TestRequestActionResult: TestRequestActionResult,
  TestAction: TestAction,
};
