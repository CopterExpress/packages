from ._SetGamma import *
