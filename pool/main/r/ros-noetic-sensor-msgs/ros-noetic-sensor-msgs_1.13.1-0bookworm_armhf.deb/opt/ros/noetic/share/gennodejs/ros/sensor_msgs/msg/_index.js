
"use strict";

let PointCloud = require('./PointCloud.js');
let JoyFeedback = require('./JoyFeedback.js');
let FluidPressure = require('./FluidPressure.js');
let CameraInfo = require('./CameraInfo.js');
let Range = require('./Range.js');
let CompressedImage = require('./CompressedImage.js');
let PointCloud2 = require('./PointCloud2.js');
let JointState = require('./JointState.js');
let Temperature = require('./Temperature.js');
let PointField = require('./PointField.js');
let LaserEcho = require('./LaserEcho.js');
let NavSatStatus = require('./NavSatStatus.js');
let BatteryState = require('./BatteryState.js');
let RelativeHumidity = require('./RelativeHumidity.js');
let NavSatFix = require('./NavSatFix.js');
let MagneticField = require('./MagneticField.js');
let MultiDOFJointState = require('./MultiDOFJointState.js');
let JoyFeedbackArray = require('./JoyFeedbackArray.js');
let Joy = require('./Joy.js');
let LaserScan = require('./LaserScan.js');
let RegionOfInterest = require('./RegionOfInterest.js');
let Illuminance = require('./Illuminance.js');
let TimeReference = require('./TimeReference.js');
let ChannelFloat32 = require('./ChannelFloat32.js');
let Image = require('./Image.js');
let MultiEchoLaserScan = require('./MultiEchoLaserScan.js');
let Imu = require('./Imu.js');

module.exports = {
  PointCloud: PointCloud,
  JoyFeedback: JoyFeedback,
  FluidPressure: FluidPressure,
  CameraInfo: CameraInfo,
  Range: Range,
  CompressedImage: CompressedImage,
  PointCloud2: PointCloud2,
  JointState: JointState,
  Temperature: Temperature,
  PointField: PointField,
  LaserEcho: LaserEcho,
  NavSatStatus: NavSatStatus,
  BatteryState: BatteryState,
  RelativeHumidity: RelativeHumidity,
  NavSatFix: NavSatFix,
  MagneticField: MagneticField,
  MultiDOFJointState: MultiDOFJointState,
  JoyFeedbackArray: JoyFeedbackArray,
  Joy: Joy,
  LaserScan: LaserScan,
  RegionOfInterest: RegionOfInterest,
  Illuminance: Illuminance,
  TimeReference: TimeReference,
  ChannelFloat32: ChannelFloat32,
  Image: Image,
  MultiEchoLaserScan: MultiEchoLaserScan,
  Imu: Imu,
};
