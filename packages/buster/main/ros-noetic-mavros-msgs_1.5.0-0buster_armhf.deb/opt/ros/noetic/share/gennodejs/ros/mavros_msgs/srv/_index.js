
"use strict";

let CommandLong = require('./CommandLong.js')
let LogRequestData = require('./LogRequestData.js')
let CommandVtolTransition = require('./CommandVtolTransition.js')
let ParamGet = require('./ParamGet.js')
let SetMavFrame = require('./SetMavFrame.js')
let CommandTriggerInterval = require('./CommandTriggerInterval.js')
let CommandHome = require('./CommandHome.js')
let SetMode = require('./SetMode.js')
let FileClose = require('./FileClose.js')
let FileWrite = require('./FileWrite.js')
let CommandInt = require('./CommandInt.js')
let ParamSet = require('./ParamSet.js')
let FileList = require('./FileList.js')
let FileRemove = require('./FileRemove.js')
let LogRequestEnd = require('./LogRequestEnd.js')
let FileRename = require('./FileRename.js')
let WaypointPull = require('./WaypointPull.js')
let ParamPull = require('./ParamPull.js')
let CommandTriggerControl = require('./CommandTriggerControl.js')
let StreamRate = require('./StreamRate.js')
let FileRemoveDir = require('./FileRemoveDir.js')
let FileTruncate = require('./FileTruncate.js')
let FileChecksum = require('./FileChecksum.js')
let VehicleInfoGet = require('./VehicleInfoGet.js')
let WaypointPush = require('./WaypointPush.js')
let WaypointClear = require('./WaypointClear.js')
let FileMakeDir = require('./FileMakeDir.js')
let FileOpen = require('./FileOpen.js')
let CommandBool = require('./CommandBool.js')
let MountConfigure = require('./MountConfigure.js')
let LogRequestList = require('./LogRequestList.js')
let WaypointSetCurrent = require('./WaypointSetCurrent.js')
let MessageInterval = require('./MessageInterval.js')
let ParamPush = require('./ParamPush.js')
let FileRead = require('./FileRead.js')
let CommandTOL = require('./CommandTOL.js')

module.exports = {
  CommandLong: CommandLong,
  LogRequestData: LogRequestData,
  CommandVtolTransition: CommandVtolTransition,
  ParamGet: ParamGet,
  SetMavFrame: SetMavFrame,
  CommandTriggerInterval: CommandTriggerInterval,
  CommandHome: CommandHome,
  SetMode: SetMode,
  FileClose: FileClose,
  FileWrite: FileWrite,
  CommandInt: CommandInt,
  ParamSet: ParamSet,
  FileList: FileList,
  FileRemove: FileRemove,
  LogRequestEnd: LogRequestEnd,
  FileRename: FileRename,
  WaypointPull: WaypointPull,
  ParamPull: ParamPull,
  CommandTriggerControl: CommandTriggerControl,
  StreamRate: StreamRate,
  FileRemoveDir: FileRemoveDir,
  FileTruncate: FileTruncate,
  FileChecksum: FileChecksum,
  VehicleInfoGet: VehicleInfoGet,
  WaypointPush: WaypointPush,
  WaypointClear: WaypointClear,
  FileMakeDir: FileMakeDir,
  FileOpen: FileOpen,
  CommandBool: CommandBool,
  MountConfigure: MountConfigure,
  LogRequestList: LogRequestList,
  WaypointSetCurrent: WaypointSetCurrent,
  MessageInterval: MessageInterval,
  ParamPush: ParamPush,
  FileRead: FileRead,
  CommandTOL: CommandTOL,
};
