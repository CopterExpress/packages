
"use strict";

let SetLEDs = require('./SetLEDs.js')
let SetLED = require('./SetLED.js')

module.exports = {
  SetLEDs: SetLEDs,
  SetLED: SetLED,
};
