
"use strict";

let CommandVtolTransition = require('./CommandVtolTransition.js')
let SetMode = require('./SetMode.js')
let FileChecksum = require('./FileChecksum.js')
let ParamGet = require('./ParamGet.js')
let FileList = require('./FileList.js')
let CommandBool = require('./CommandBool.js')
let ParamPush = require('./ParamPush.js')
let FileOpen = require('./FileOpen.js')
let LogRequestList = require('./LogRequestList.js')
let WaypointClear = require('./WaypointClear.js')
let ParamSet = require('./ParamSet.js')
let CommandTriggerInterval = require('./CommandTriggerInterval.js')
let WaypointPull = require('./WaypointPull.js')
let StreamRate = require('./StreamRate.js')
let LogRequestEnd = require('./LogRequestEnd.js')
let MountConfigure = require('./MountConfigure.js')
let LogRequestData = require('./LogRequestData.js')
let CommandInt = require('./CommandInt.js')
let CommandAck = require('./CommandAck.js')
let WaypointSetCurrent = require('./WaypointSetCurrent.js')
let CommandTriggerControl = require('./CommandTriggerControl.js')
let MessageInterval = require('./MessageInterval.js')
let FileRead = require('./FileRead.js')
let FileRemove = require('./FileRemove.js')
let FileMakeDir = require('./FileMakeDir.js')
let ParamPull = require('./ParamPull.js')
let SetMavFrame = require('./SetMavFrame.js')
let CommandLong = require('./CommandLong.js')
let CommandTOL = require('./CommandTOL.js')
let VehicleInfoGet = require('./VehicleInfoGet.js')
let CommandHome = require('./CommandHome.js')
let WaypointPush = require('./WaypointPush.js')
let FileTruncate = require('./FileTruncate.js')
let FileRemoveDir = require('./FileRemoveDir.js')
let FileRename = require('./FileRename.js')
let FileWrite = require('./FileWrite.js')
let FileClose = require('./FileClose.js')

module.exports = {
  CommandVtolTransition: CommandVtolTransition,
  SetMode: SetMode,
  FileChecksum: FileChecksum,
  ParamGet: ParamGet,
  FileList: FileList,
  CommandBool: CommandBool,
  ParamPush: ParamPush,
  FileOpen: FileOpen,
  LogRequestList: LogRequestList,
  WaypointClear: WaypointClear,
  ParamSet: ParamSet,
  CommandTriggerInterval: CommandTriggerInterval,
  WaypointPull: WaypointPull,
  StreamRate: StreamRate,
  LogRequestEnd: LogRequestEnd,
  MountConfigure: MountConfigure,
  LogRequestData: LogRequestData,
  CommandInt: CommandInt,
  CommandAck: CommandAck,
  WaypointSetCurrent: WaypointSetCurrent,
  CommandTriggerControl: CommandTriggerControl,
  MessageInterval: MessageInterval,
  FileRead: FileRead,
  FileRemove: FileRemove,
  FileMakeDir: FileMakeDir,
  ParamPull: ParamPull,
  SetMavFrame: SetMavFrame,
  CommandLong: CommandLong,
  CommandTOL: CommandTOL,
  VehicleInfoGet: VehicleInfoGet,
  CommandHome: CommandHome,
  WaypointPush: WaypointPush,
  FileTruncate: FileTruncate,
  FileRemoveDir: FileRemoveDir,
  FileRename: FileRename,
  FileWrite: FileWrite,
  FileClose: FileClose,
};
